<?php $__env->startSection('content'); ?>
<main class="main-wrapper">
    <!-- Start Breadcrumb Area  -->
    <div class="axil-breadcrumb-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-8">
                    <div class="inner">
                        
                        <h1 class="title">Consulter notre catalogue</h1>
                    </div>
                </div>
                <div class="col-lg-6 col-md-4">
                    <div class="inner">
                        <div class="bradcrumb-thumb">
                            <img src="<?php echo e(asset('assets-admin/images/product-45.png')); ?>" alt="Image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb Area  -->

    <!-- Start Shop Area  -->
    <div class="axil-shop-area axil-section-gap bg-color-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="axil-shop-sidebar">
                        <div class="d-lg-none">
                            <button class="sidebar-close filter-close-btn"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="toggle-list product-categories active">
                            <h6 class="title">CATEGORIES</h6>
                            <div class="shop-submenu">
                                <ul>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <li><a href="/catalogue/<?php echo e($categories->category); ?>"><?php echo e($categories->category); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </ul>
                            </div>
                        </div>

                        

                        
                        
                    </div>
                    <!-- End .axil-shop-sidebar -->
                </div>
                <div class="col-lg-9">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="axil-shop-top mb--40">
                                <div class="category-select align-items-center justify-content-lg-end justify-content-between">
                                    <!-- Start Single Select  -->
                                    <span class="filter-results">Recherche par</span>
                                    <select  class="single-select">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categories->category); ?>"><?php echo e($categories->category); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                    </select>
                                    <script>
                                        // go to url catalogue/category on select change
                                        document.querySelector('.single-select').addEventListener('change', function() {
                                            window.location.href = '/catalogue/'+this.value;
                                        });
                                    </script>
                                    <!-- End Single Select  -->
                                </div>
                                <div class="d-lg-none d-none">
                                    <button class="product-filter-mobile filter-toggle"><i class="fas fa-filter"></i> FILTER</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End .row -->
                    <div class="row row--15">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-4 col-sm-6">
                            <div class="axil-product product-style-one mb--30">
                                <div class="thumbnail">
                                    <a href="#">
                                        <img src="<?php echo e(asset('images/'.$item->image)); ?>" alt="Product Images">
                                    </a>
                                    <?php if($item->prix_promo!=0): ?>

                                    <div class="label-block label-right">
                                        <div class="product-badget">PRIX PROMO: <?php echo e($item->prix_promo); ?> €</div>
                                    </div>
                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                    <div class="product-hover-action">
                                        
                                    </div>
                                </div>
                                <div class="product-content">
                                    <div class="inner">
                                        <h5 class="title"><a href=""><?php echo e($item->libelle); ?></a></h5>
                                        
                                        <div class="product-price-variant">
                                            <span class="price current-price">
                                                <?php if($item->prix_promo!=0): ?>
                                                <span class="text-danger"><?php echo e($item->prix_promo); ?>€</span>
                                                <?php else: ?>
                                                <?php echo e($item->prix); ?>€
                                                <?php endif; ?>
                                            </span>
                                           
                                        </div>

                                        <p>
                                            <?php
                                                $description = html_entity_decode($item->description);
                                                $description = strip_tags($description);
    
                                                echo $description;
                                                
                                            ?>
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                    </div>
                    <div class="text-center pt--20 d-none">
                        <a href="#" class="axil-btn btn-bg-lighter btn-load-more">Load more</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End .container -->
    </div>
    <!-- End Shop Area  -->

    
</main>


<div class="service-area">
    <div class="container">
        <div class="row row-cols-xl-4 row-cols-sm-2 row-cols-1 row--20 d-flex justify-content-center">
            <div class="col">
                <div class="service-box service-style-2">
                    <div class="icon">
                        <img src="<?php echo e(asset('assets-admin/images/icons/service1.png')); ?>" alt="Service">
                    </div>
                    <div class="content">
                        <h6 class="title">Rapide et livraison &amp; sécurisée</h6>
                        
                    </div>
                </div>
            </div>
           
            <div class="col">
                <div class="service-box service-style-2">
                    <div class="icon">
                        <img src="<?php echo e(asset('assets-admin/images/icons/service3.png')); ?>" alt="Service">
                    </div>
                    <div class="content">
                        <h6 class="title">Retour et remboursement</h6>
                        <p>Oui, possible</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="service-box service-style-2">
                    <div class="icon">
                        <img src="<?php echo e(asset('assets-admin/images/icons/service4.png')); ?>" alt="Service">
                    </div>
                    <div class="content">
                        <h6 class="title">Support</h6>
                        <p>24/7 support par mail.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mini-boutiques/resources/views/shop.blade.php ENDPATH**/ ?>