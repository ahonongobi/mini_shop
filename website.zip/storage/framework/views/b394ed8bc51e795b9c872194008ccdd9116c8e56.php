<?php $__env->startSection('content'); ?>

<div class="container">
    
    <form style="padding: 10px" action="<?php echo e(URL('addproductpost')); ?>" method="post" enctype="multipart/form-data">
        
        
        <div class="section-block mt-5">
          
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($item); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <h2>Créer un produit</h2>
        </div>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input class="form-control" type="text" name="libelle"
                id="key" placeholder="Un libelle">
        </div>
        
        
        <div class="form-group">
            <input class="form-control" type="text" name="prix"
                id="key" placeholder="Prix">
        </div>
        <div class="form-group">
            <div class="form-label-group">
              <select name="category" class="custom-select" id="fls1">
                <option value=""> Choisir... </option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                <option value="<?php echo e($item->category); ?>"> <?php echo e($item->category); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select> <label for="fls1">Categorie</label>
            </div>
          </div>
          <div class="form-group">
            <label for="tf3">Image</label>
            <div class="custom-file">
              <input type="file" name="image" class="custom-file-input" id="tf3"> <label class="custom-file-label" for="tf3">Choisir un fichier</label>
            </div>
          </div>
          <div class="form-group">
            <textarea name="description" id="mytextarea">Hello, World!</textarea>
          </div>
        
    
        <button class="btn btn-primary">Enregister</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mini-boutiques/resources/views/admin/add-product.blade.php ENDPATH**/ ?>