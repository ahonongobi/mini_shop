<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><!-- End Required meta tags -->
    <!-- Begin SEO tag -->
    <title> Admin invoice </title>
    <meta property="og:title" content="Basic Table">
    <meta name="author" content="Beni Arisandi">
    <meta property="og:locale" content="en_US">
    <meta name="description" content="Responsive admin theme build on top of Bootstrap 4">
    <meta property="og:description" content="Responsive admin theme build on top of Bootstrap 4">
    <link rel="canonical" href="index-2.html">
    <meta property="og:url" content="index-2.html">
    <meta property="og:site_name" content="Looper - Bootstrap 4 Admin Theme">
    <script type="application/ld+json">
      {
        "name": "Looper - Bootstrap 4 Admin Theme",
        "description": "Responsive admin theme build on top of Bootstrap 4",
        "author":
        {
          "@type": "Person",
          "name": "Beni Arisandi"
        },
        "@type": "WebSite",
        "url": "",
        "headline": "Basic Table",
        "@context": "http://schema.org"
      }
    </script><!-- End SEO tag -->
    <!-- FAVICONS -->
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('assets/apple-touch-icon.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/favicon.ico')); ?>">
    <meta name="theme-color" content="#3063A0"><!-- End FAVICONS -->
    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,600" rel="stylesheet"><!-- End GOOGLE FONT -->
    <!-- BEGIN PLUGINS STYLES -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/open-iconic/font/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/%40fortawesome/fontawesome-free/css/all.min.css')); ?>">
    <!-- END PLUGINS STYLES -->
    <!-- BEGIN THEME STYLES -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/stylesheets/theme.min.css')); ?>" data-skin="default">
    <link rel="stylesheet" href="<?php echo e(asset('assets/stylesheets/theme-dark.min.css')); ?>" data-skin="dark">
    <link rel="stylesheet" href="<?php echo e(asset('assets/stylesheets/custom.css')); ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <script>
        var skin = localStorage.getItem('skin') || 'default';
        var disabledSkinStylesheet = document.querySelector('link[data-skin]:not([data-skin="' + skin + '"])');
        // Disable unused skin immediately
        disabledSkinStylesheet.setAttribute('rel', '');
        disabledSkinStylesheet.setAttribute('disabled', true);
        // add loading class to html immediately
        document.querySelector('html').classList.add('loading');
    </script><!-- END THEME STYLES -->
    <script src="https://cdn.tiny.cloud/1/7u3r7qea3yrq1hrwqqd2v3ocyc39hxgn6q4rqwvvw9wkr1ib/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
          selector: '#mytextarea'
        });
      </script>
</head>

<body>

    <header class="app-header app-header-dark mb-5">
        <!-- .top-bar -->
        <div class="top-bar">
            <!-- .top-bar-brand -->
            <div class="top-bar-brand">
                <!-- toggle aside menu -->
                <button class="hamburger hamburger-squeeze mr-2" type="button" data-toggle="aside-menu"
                    aria-label="toggle aside menu"><span class="hamburger-box"><span
                            class="hamburger-inner"></span></span></button> <!-- /toggle aside menu -->
                <a href="/home">
                    <img src="<?php echo e(asset('assets/images/logo/logo-light.png')); ?>" alt="logo" >
                </a>
            </div><!-- /.top-bar-brand -->
            <!-- .top-bar-list -->
            <div class="top-bar-list">
                <!-- .top-bar-item -->
                <div class="top-bar-item px-2 d-md-none d-lg-none d-xl-none">
                    <!-- toggle menu -->
                    <button class="hamburger hamburger-squeeze" type="button" data-toggle="aside"
                        aria-label="toggle menu"><span class="hamburger-box"><span
                                class="hamburger-inner"></span></span></button> <!-- /toggle menu -->
                </div><!-- /.top-bar-item -->
                <!-- .top-bar-item -->
                <div class="top-bar-item top-bar-item-full">
                    <!-- .top-bar-search -->
                    <form class="top-bar-search">
                        <!-- .input-group -->
                        <div class="input-group input-group-search dropdown">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><span class="oi oi-magnifying-glass"></span></span>
                            </div><input type="text" class="form-control" data-toggle="dropdown"
                                aria-label="Search" placeholder="Rechercher"> <!-- .dropdown-menu -->
                            <div class="dropdown-menu dropdown-menu-rich dropdown-menu-xl ml-n4 mw-100">
                                <div class="dropdown-arrow ml-3"></div><!-- .dropdown-scroll -->
                                <div class="dropdown-scroll perfect-scrollbar h-auto" style="max-height: 360px">
                                    <!-- .list-group -->
                                    <div class="list-group list-group-flush list-group-reflow mb-2">
                                        <h6 class="list-group-header d-flex justify-content-between">
                                            <span>Raccourci</span>
                                        </h6><!-- .list-group-item -->
                                        <div class="list-group-item py-2">
                                            <a href="/addproduct"
                                                class="stretched-link"></a>
                                            <div class="tile tile-sm bg-muted">
                                                <i class="fas fa-user-plus"></i>
                                            </div>
                                            <div class="ml-2"> Ajouter un produit</div>
                                        </div><!-- /.list-group-item -->
                                        <!-- .list-group-item -->
                                        <div class="list-group-item py-2">
                                            <a href="/home" class="stretched-link"></a>
                                            <div class="tile tile-sm bg-muted">
                                                <i class="fas fa-dollar-sign"></i>
                                            </div>
                                            <div class="ml-2"> Liste des produits </div>
                                        </div><!-- /.list-group-item -->
                                        <!-- /.list-group-item -->
                                    </div><!-- /.list-group -->
                                </div><!-- /.dropdown-scroll -->

                            </div><!-- /.dropdown-menu -->
                        </div><!-- /.input-group -->
                    </form><!-- /.top-bar-search -->
                </div><!-- /.top-bar-item -->
                <!-- .top-bar-item -->
                <div class="top-bar-item top-bar-item-right px-0 d-none d-sm-flex">
                    <!-- .nav -->
                    <ul class="header-nav nav">
                        <!-- .nav-item -->
                        <!-- /.nav-item -->
                        <!-- .nav-item -->
                        <!-- /.nav-item -->
                        <!-- .nav-item -->
                        <li class="nav-item dropdown header-nav-dropdown">
                            <a class="nav-link" href="#" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false"><span class="oi oi-grid-three-up"></span></a>
                            <!-- .dropdown-menu -->
                            <div class="dropdown-menu dropdown-menu-rich dropdown-menu-right">
                                <div class="dropdown-arrow"></div><!-- .dropdown-sheets -->
                                <div class="dropdown-sheets">
                                    <!-- .dropdown-sheet-item -->
                                    <div class="dropdown-sheet-item">
                                        <a href="/category"
                                            class="tile-wrapper"><span class="tile tile-lg bg-indigo"><i
                                                    class="oi oi-flag"></i></span> <span
                                                class="tile-peek">Categorie</span></a>
                                    </div><!-- /.dropdown-sheet-item -->
                                    <!-- .dropdown-sheet-item -->
                                    <div class="dropdown-sheet-item">
                                        <a href="/ajouterpromo" class="tile-wrapper"><span
                                                class="tile tile-lg bg-teal"><i class="oi oi-tag"></i></span>
                                            <span class="tile-peek">Promotion</span></a>
                                    </div><!-- /.dropdown-sheet-item -->
                                    <!-- .dropdown-sheet-item -->
                                    <!-- /.dropdown-sheet-item -->
                                </div><!-- .dropdown-sheets -->
                            </div><!-- .dropdown-menu -->
                        </li><!-- /.nav-item -->
                    </ul><!-- /.nav -->
                    <!-- .btn-account -->
                    <div class="dropdown d-none d-md-flex">
                        <button class="btn-account" type="button" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false"><span class="user-avatar user-avatar-md"><img
                                    src="https://i.postimg.cc/jSxkrxBQ/pngtree-user-vector-avatar-png-image-1541962.jpg"
                                    alt=""></span> <span
                                class="account-summary pr-lg-4 d-none d-lg-block"><span
                                    class="account-name">Admin</span> <span
                                    class="account-description"></span></span></button> <!-- .dropdown-menu -->
                        <div class="dropdown-menu">
                            <div class="dropdown-arrow d-lg-none" x-arrow=""></div>
                            <div class="dropdown-arrow ml-3 d-none d-lg-block"></div>
                            <a class="dropdown-item d-none" href="/logout"><span
                                    class="dropdown-icon oi oi-person"></span> Profile</a> <a
                                class="dropdown-item" href="/logout"><span
                                    class="dropdown-icon oi oi-account-logout"></span>Deconnexion</a>
                        </div><!-- /.dropdown-menu -->
                    </div><!-- /.btn-account -->
                </div><!-- /.top-bar-item -->
            </div><!-- /.top-bar-list -->
        </div><!-- /.top-bar -->
    </header><!-- /.app-header -->
    <!-- .app-aside -->
    <aside class="app-aside app-aside-expand-md app-aside-light">
        <!-- .aside-content -->
        <div class="aside-content">
            <!-- .aside-header -->
            <header class="aside-header d-block d-md-none">
                <!-- .btn-account -->
                <button class="btn-account" type="button" data-toggle="collapse"
                    data-target="#dropdown-aside"><span class="user-avatar user-avatar-lg"><img
                            src="https://i.postimg.cc/jSxkrxBQ/pngtree-user-vector-avatar-png-image-1541962.jpg"
                            alt=""></span> <span class="account-icon"><span
                            class="fa fa-caret-down fa-lg"></span></span> <span class="account-summary"><span
                            class="account-name"><?php echo e(Auth::user()->name); ?></span> <span class="account-description">Administrateur</span></span></button> <!-- /.btn-account -->
                <!-- .dropdown-aside -->
                <div id="dropdown-aside" class="dropdown-aside collapse">
                    <!-- dropdown-items -->
                    <div class="pb-3">
                        <a class="dropdown-item"
                            href="/logout"><span class="dropdown-icon oi oi-account-logout"></span>
                            Deconnexion</a>
                        <div class="dropdown-divider"></div>
                    </div><!-- /dropdown-items -->
                </div><!-- /.dropdown-aside -->
            </header><!-- /.aside-header -->
            <!-- .aside-menu -->
            <div class="aside-menu overflow-hidden">
                <!-- .stacked-menu -->
                <nav id="stacked-menu" class="stacked-menu">
                    <!-- .menu -->
                    <ul class="menu">
                        <!-- .menu-item -->
                        <li class="menu-item">
                            <a href="/home" class="menu-link"><span class="menu-icon fas fa-home"></span> <span
                                    class="menu-text">Dashboard</span></a>
                        </li><!-- /.menu-item -->
                        <!-- .menu-item -->
                        <li class="menu-item">
                            <a href="/addproduct" class="menu-link"><span class="menu-icon fas fa-plus"></span> <span
                                    class="menu-text">Créer un produit</span></a>
                        </li>

                        <li class="menu-item">
                            <a href="/category" class="menu-link"><span class="menu-icon fas fa-list-alt"></span> <span
                                    class="menu-text">Catégories</span></a>
                        </li>

                        <li class="menu-item">
                            <a href="/ajouterpromo" class="menu-link"><span class="menu-icon fas fa-tag"></span> <span
                                    class="menu-text">Promo</span></a>
                        </li>



                        <li class="menu-item">
                            <a href="/logout" class="menu-link"><span class="menu-icon fas fa-power-off"></span>
                                <span class="menu-text">Deconnexion</span></a>
                        </li><!-- /.menu-item -->
                        <!-- .menu-header -->

                    </ul><!-- /child menu -->
                    </li><!-- /.menu-item -->
                    </ul><!-- /.menu -->
                </nav><!-- /.stacked-menu -->
            </div><!-- /.aside-menu -->
            <!-- Skin changer -->
            <footer class="aside-footer border-top p-2">
                <button class="btn btn-light btn-block text-primary" data-toggle="skin"><span
                        class="d-compact-menu-none">Mode sombre</span> <i class="fas fa-moon ml-1"></i></button>
            </footer><!-- /Skin changer -->
        </div><!-- /.aside-content -->
    </aside><!-- /.app-aside -->
    <!-- .app -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- /.app -->
    <!-- BEGIN BASE JS -->
    <script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('assets/vendor/popper.js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script> <!-- END BASE JS -->
    <!-- BEGIN PLUGINS JS -->
    <script src="<?php echo e(asset('assets/vendor/pace-progress/pace.min.js')); ?>"></script>
    <script src="assets/vendor/stacked-menu/js/stacked-menu.min.js"></script>
    <script src="<?php echo e(asset('assets/vendor/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script> <!-- END PLUGINS JS -->
    <!-- BEGIN THEME JS -->
    <script src="<?php echo e(asset('assets/javascript/theme.min.js')); ?>"></script> <!-- END THEME JS -->
    <!-- BEGIN PAGE LEVEL JS -->
    <script src="<?php echo e(asset('assets/javascript/pages/table-demo.js')); ?>"></script> <!-- END PAGE LEVEL JS -->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-116692175-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-116692175-1');
    </script>

    <script>
        function pending() {
            alert(
                "Vous etes sur le pont d'envoyer la facture. Veuillez patienter, votre connexion est faible. cela peut prendre jusqu'a 2minutes");

            // show the div with id pending
            document.getElementById("pending").style.display = "block";
        }
        // on page load, set skin key to dark
        localStorage.setItem('skin', 'dark');
    </script>
    <script>
        // define send_message function that take id as parameter and send message to database with ajax GET request method send_message/{id}
        function send_message(id, nom) {
            $('#message_id').val(id);
            $('#label_message').text('Message a '+nom);
            // open modalTable2 modal 
            $('#modalTable2').modal('show');

           /* $.ajax({
                url: 'send_message/' + id,
                type: 'GET',
                success: function(data) {
                    // if success, show success message
                    alert('Message sent successfully to id N'+id);
                }
            }); **/
        }
        

    </script>
    <script>
        

        function appliquer_promo(id, libbelle) {
            $('#message_id').val(id);
            $('#label_message').text('Message a '+libbelle);
            // open modalTable2 modal 
            $('#modalTable2').modal('show');

           /* $.ajax({
                url: 'send_message/' + id,
                type: 'GET',
                success: function(data) {
                    // if success, show success message
                    alert('Message sent successfully to id N'+id);
                }
            }); **/
        }
    </script>

<script>
    tinymce.init({
      selector: 'textarea',
      plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange export formatpainter pageembed linkchecker a11ychecker tinymcespellchecker permanentpen powerpaste advtable advcode editimage tinycomments tableofcontents footnotes mergetags autocorrect typography inlinecss',
      toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
      tinycomments_mode: 'embedded',
      tinycomments_author: 'Author name',
      mergetags_list: [
        { value: 'First.Name', title: 'First Name' },
        { value: 'Email', title: 'Email' },
      ]
    });
  </script>
  <script>
    $(document).ready(function () {
    $('#example').DataTable(
        // in french
        {
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json"
            },

            // hide Affichage de l'élément 1 à 2 sur 2 éléments
            "info": false,
            
        }
    );
    
    
});
  </script>
</body>

</html>


<?php /**PATH /opt/lampp/htdocs/mini-boutiques/resources/views/layouts/_layouts.blade.php ENDPATH**/ ?>