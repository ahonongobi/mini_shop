<?php $__env->startSection('content'); ?>

<div class="container">
    
    <form style="padding: 10px" action="<?php echo e(URL('addcategory')); ?>" method="post">
        <div class="section-block mt-5">
            <div class="table-responsive">
                <!-- .table -->
                <table class="table">
                    <!-- thead -->
                    <thead>
                        <tr>
        
                            <th> Nom </th>
                            
                            
                            <th style="width:100px; min-width:100px;"> &nbsp; </th>
                        </tr>
                    </thead><!-- /thead -->
                    <!-- tbody -->
                    <tbody>
                        <!-- tr -->
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
        
        
                                <td class="align-middle"> <?php echo e($item->category); ?> </td>
                                
                                <td class="align-middle text-right">
                                    <a onclick="return confirm('Voulez-vous supprimer cette categorie ?')"
                                        class="btn btn-sm  btn-icon btn-secondary"><i
                                            class="fa fa-trash"></i> <span
                                            class="sr-only">trash</span></a> 
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
                    </tbody><!-- /tbody -->
                </table>
            </div>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <h2>Créer une Catégorie</h2>
        </div>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input required class="form-control" type="text" name="category"
                id="key" placeholder="Category">
        </div>
    
        <button class="btn btn-primary">Enregister</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mini-boutiques/resources/views/admin/category.blade.php ENDPATH**/ ?>