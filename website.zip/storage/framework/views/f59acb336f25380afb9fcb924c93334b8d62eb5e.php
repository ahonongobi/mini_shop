<?php $__env->startSection('content'); ?>

<div class="container">
    
    <form style="padding: 10px" action="<?php echo e(URL('addpromo')); ?>" method="post">
        <div class="section-block mt-5">
            <div class="table-responsive">
                <!-- .table -->
                <table class="table">
                    <!-- thead -->
                    <thead>
                        <tr>
        
                            <th> Promo </th>
                            <th>Date de debut</th>
                            <th>Date de fin</th>
                            
                            
                            <th style="width:100px; min-width:100px;"> &nbsp; </th>
                        </tr>
                    </thead><!-- /thead -->
                    <!-- tbody -->
                    <tbody>
                        <!-- tr -->
                        <?php $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
        
        
                                <td class="align-middle"> <?php echo e($item->reduction); ?> </td>
                                <td class="align-middle"> <?php echo e($item->date_debut); ?> </td>
                                <td class="align-middle"> <?php echo e($item->date_fin); ?> </td>
                                
                                <td class="align-middle text-right">
                                    <a onclick="return confirm('Voulez-vous supprimer cette categorie ?')"
                                        class="btn btn-sm  btn-icon btn-secondary"><i
                                            class="fa fa-trash"></i> <span
                                            class="sr-only">trash</span></a> 
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
                    </tbody><!-- /tbody -->
                </table>
            </div>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <h2>Créer une Promotion</h2>
        </div>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input required class="form-control" type="text" name="promo"
                id="key" placeholder="Promo reduction en % (Ex: 10)">
        </div>
        <div class="form-group">
            <input required class="form-control" type="date" name="date_debut"
                id="key" placeholder="Date de debut">
        </div>
        <div class="form-group">
            <input required class="form-control" type="date" name="date_fin"
                id="key" placeholder="Date de fin">
        </div>
    
        <button class="btn btn-primary">Enregister</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mini-boutiques/resources/views/admin/ajouterpromo.blade.php ENDPATH**/ ?>